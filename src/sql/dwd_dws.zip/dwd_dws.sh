#!/bin/bash
hive -f dwd_dws.sql