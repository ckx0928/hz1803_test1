#!/bin/bash
hive -f load_data_dm.sql