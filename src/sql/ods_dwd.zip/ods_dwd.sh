#!/bin/bash
hive -f ods_dwd.sql